window.DB = (function(){
  const k = (x)=>'SKS_'+x;
  const get = (key, def)=> { try{ return JSON.parse(localStorage.getItem(k(key))) ?? def; }catch(e){ return def; } };
  const set = (key, val)=> localStorage.setItem(k(key), JSON.stringify(val));
  const del = (key)=> localStorage.removeItem(k(key));
  return { get,set,del };
})();