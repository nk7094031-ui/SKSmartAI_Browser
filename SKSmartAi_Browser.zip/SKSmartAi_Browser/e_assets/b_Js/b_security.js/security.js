window.SAFE = (function(){
  const DEFAULT = true;
  const BAD = [
    "adult","xxx","porn","cp","drugs","credit card dump","hack tool","malware",
    "torrent illegal","crack software","keygen","carding","ddos","botnet"
  ];
  function isBlocked(text){
    const t = String(text||"").toLowerCase();
    return BAD.some(k => t.includes(k));
  }
  function on(){ return DB.get('safe_mode', DEFAULT) === true; }
  function set(v){ DB.set('safe_mode', !!v); }
  return { isBlocked, on, set };
})();