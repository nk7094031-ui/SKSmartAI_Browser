window.AI = (function(){
  async function instant(q){
    // DuckDuckGo Instant Answer (no key)
    const url = `https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&no_redirect=1`;
    const r = await fetch(url); const j = await r.json();
    let out = j.AbstractText || '';
    if(!out && j.RelatedTopics && j.RelatedTopics.length){
      const pick = j.RelatedTopics[0];
      out = (pick.Text || pick.Name || '');
    }
    return out || 'No instant answer.';
  }
  async function viaBackend(q){
    const ep = DB.get('ai_ep','');
    if(!ep) return null;
    try{
      const r = await fetch(ep, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({prompt:q})});
      const j = await r.json();
      if(j.ok && j.answer) return j.answer;
      return j.answer || null;
    }catch(e){ return null; }
  }
  return { instant, viaBackend };
})();