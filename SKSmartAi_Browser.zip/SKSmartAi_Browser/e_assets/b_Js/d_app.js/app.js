(function(){
  const q = document.getElementById('q');
  const engineSel = document.getElementById('engine');
  const goBtn = document.getElementById('go');
  const aiBtn = document.getElementById('aiBtn');
  const view = document.getElementById('view');
  const status = document.getElementById('status');

  // Tabs
  document.querySelectorAll('.tabs button').forEach(b=>{
    b.addEventListener('click', ()=>{
      document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));
      b.classList.add('active');
      document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
      document.getElementById('tab-'+b.dataset.tab).classList.add('active');
    });
  });

  // Bookmarks
  const bmList = document.getElementById('bookmarks');
  const bmAdd = document.getElementById('bm-add');
  const bmTitle = document.getElementById('bm-title');
  const bmUrl = document.getElementById('bm-url');
  function renderBM(){
    const b = DB.get('bm',[]);
    bmList.innerHTML = b.map(x=>`<a href="#" data-href="${x.url}">★ ${x.title}</a>`).join('') || '<small class="muted">No bookmarks yet.</small>';
  }
  bmList.addEventListener('click', (e)=>{
    const a = e.target.closest('a'); if(!a) return;
    e.preventDefault(); openUrl(a.dataset.href); document.querySelector('[data-tab="web"]').click();
  });
  bmAdd.addEventListener('click', ()=>{
    const title = bmTitle.value.trim() || 'Link';
    const url = normalizeUrl(bmUrl.value.trim());
    if(!url) return alert('Enter a valid URL');
    const arr = DB.get('bm',[]); arr.push({title,url}); DB.set('bm',arr);
    bmTitle.value=''; bmUrl.value=''; renderBM();
  });
  renderBM();

  // Apps grid
  const appGrid = document.getElementById('app-grid');
  const appAdd = document.getElementById('app-add');
  const appTitle = document.getElementById('app-title');
  const appUrl = document.getElementById('app-url');
  function renderApps(){
    const a = DB.get('apps',[]);
    appGrid.innerHTML = a.map(x=>`<a class="tile" target="_blank" href="${x.url}">${x.title}</a>`).join('') || '<small class="muted">No apps yet.</small>';
  }
  appAdd.addEventListener('click', ()=>{
    const title = appTitle.value.trim() || 'App';
    const url = normalizeUrl(appUrl.value.trim());
    if(!url) return alert('Enter a valid URL');
    const arr = DB.get('apps',[]); arr.push({title,url}); DB.set('apps',arr);
    appTitle.value=''; appUrl.value=''; renderApps();
  });
  renderApps();
  
    // Notes
  const noteArea = document.getElementById('note-area');
  const noteAdd = document.getElementById('note-add');
  const noteTitle = document.getElementById('note-title');
  const noteList = document.getElementById('note-list');
  function renderNotes(){
    const arr = DB.get('notes',[]);
    noteList.innerHTML = arr.map((n,i)=>`<div class="card"><b>${n.title}</b><div class="muted small">${new Date(n.ts).toLocaleString()}</div><div class="small">${escapeHtml(n.body).slice(0,250)}</div><button data-i="${i}" class="note-open">Open</button></div>`).join('') || '<small class="muted">No notes yet.</small>';
  }
  noteAdd.addEventListener('click', ()=>{
    const title = noteTitle.value.trim() || 'Note';
    const body = noteArea.value.trim();
    const arr = DB.get('notes',[]); arr.unshift({title, body, ts: Date.now()}); DB.set('notes',arr);
    noteTitle.value=''; noteArea.value=''; renderNotes();
  });
  noteList.addEventListener('click', (e)=>{
    const b = e.target.closest('.note-open'); if(!b) return;
    const i = +b.dataset.i; const n = DB.get('notes',[])[i];
    noteTitle.value = n.title; noteArea.value = n.body;
    document.querySelector('[data-tab="notes"]').click();
  });
  renderNotes();

  // Blog
  const blogTitle = document.getElementById('blog-title');
  const blogEditor = document.getElementById('blog-editor');
  document.getElementById('blog-save').onclick = ()=> DB.set('blog',{title: blogTitle.value.trim(), body: blogEditor.value});
  document.getElementById('blog-export').onclick = ()=>{
    const data = DB.get('blog',{title:'blog',body:''});
    const blob = new Blob([data.body||''],{type:'text/markdown'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = (data.title||'blog') + '.md'; a.click(); URL.revokeObjectURL(a.href);
  };
  document.getElementById('blog-clear').onclick = ()=>{ if(confirm('Clear blog?')){ DB.set('blog',{title:'',body:''}); blogTitle.value=''; blogEditor.value=''; } };
  (function restoreBlog(){ const b = DB.get('blog',null); if(b){ blogTitle.value=b.title||''; blogEditor.value=b.body||''; } })();

  // Wallet (demo)
  const walAdd = document.getElementById('wal-add');
  const walLabel = document.getElementById('wal-label');
  const walAddr = document.getElementById('wal-addr');
  const walList = document.getElementById('wal-list');
  function renderWal(){
    const w = DB.get('wallets',[]);
    walList.innerHTML = w.map((x,i)=>`<div class="row"><b>${x.label}</b><span class="small muted">${x.addr}</span><button data-i="${i}" class="wal-del">Delete</button></div>`).join('') || '<small class="muted">No wallets (demo) yet.</small>';
  }
  walAdd.onclick = ()=>{
    const label = walLabel.value.trim()||'Wallet';
    const addr = walAddr.value.trim();
    if(!addr) return alert('Paste a public address (demo).');
    const arr = DB.get('wallets',[]); arr.push({label, addr}); DB.set('wallets',arr);
    walLabel.value=''; walAddr.value=''; renderWal();
  };
  
walList.addEventListener('click', (e)=>{ const b=e.target.closest('.wal-del'); if(!b) return; const i=+b.dataset.i; const arr=DB.get('wallets',[]); arr.splice(i,1); DB.set('wallets',arr); renderWal();});
  renderWal();

  // Builder
  const wbTitle = document.getElementById('wb-title');
  const wbHeading = document.getElementById('wb-heading');
  const wbBody = document.getElementById('wb-body');
  const wbView = document.getElementById('wb-view');
  document.getElementById('wb-preview').onclick = ()=>{
    const html = siteTemplate(wbTitle.value, wbHeading.value, wbBody.value);
    wbView.srcdoc = html;
  };
  document.getElementById('wb-export').onclick = ()=>{
    const html = siteTemplate(wbTitle.value, wbHeading.value, wbBody.value);
    const blob = new Blob([html],{type:'text/html'}); const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='site.html'; a.click(); URL.revokeObjectURL(a.href);
  };
  function siteTemplate(title, heading, body){
    return `<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title||'My Site')}</title><style>body{font:16px system-ui;background:#0b0f14;color:#e7eef5;padding:16px}a{color:#5cc8ff}.hero{font-size:28px;font-weight:700;margin:10px 0}</style><h1>${escapeHtml(heading||'Welcome')}</h1><div>${escapeHtml(body||'Write something great!').replace(/\\n/g,'<br>')}</div>`;
  }

  // App Builder JSON
  const abJson = document.getElementById('ab-json');
  document.getElementById('ab-load').onclick = ()=>{
    try{
      const arr = JSON.parse(abJson.value||'[]');
      if(!Array.isArray(arr)) throw 0;
      DB.set('apps', arr.map(x=>({title:String(x.title||'App'), url:String(x.url||'')})).filter(x=>x.url));
      renderApps(); alert('Loaded to Apps.');
    }catch{ alert('Invalid JSON'); }
  };
  document.getElementById('ab-export').onclick = ()=>{
    const arr = DB.get('apps',[]);
    const blob = new Blob([JSON.stringify(arr,null,2)],{type:'application/json'});
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download='apps.json'; a.click(); URL.revokeObjectURL(a.href);
  };

  // Search / navigation + Safe Mode
  function normalizeUrl(t){
    if(!t) return '';
    try{ new URL(t); return t; }catch(e){}
    if(/^[a-z0-9.-]+\\.[a-z]{2,}$/i.test(t)) return 'https://'+t;
    return '';
  }
  function engineUrl(q, eng){
    if (SAFE.on() && SAFE.isBlocked(q)) return alert('Blocked by Safe Mode.');
    const e = eng || engineSel.value, enc = encodeURIComponent(q);
    if (isUrlLike(q)) return normalizeUrl(q) || ('https://'+q);
    switch(e){
      case 'ddg': return `https://duckduckgo.com/?q=${enc}`;
      case 'bing': return `https://www.bing.com/search?q=${enc}`;
      case 'yt': return `https://www.youtube.com/results?search_query=${enc}`;
      case 'wiki': return `https://en.wikipedia.org/wiki/Special:Search?search=${enc}`;
      default: return `https://www.google.com/search?q=${enc}`;
    }
  }
  function isUrlLike(q){ try{ new URL(q); return true; }catch(e){} return /^[a-z0-9.-]+\\.[a-z]{2,}$/i.test(q); }
  function openUrl(u){ if(!u) return; document.querySelector('[data-tab="web"]').click(); view.src = u; status.textContent='Loading…'; }
  goBtn.onclick = ()=>{ const text = q.value.trim(); openUrl(engineUrl(text)); };
  q.addEventListener('keydown', e=>{ if(e.key==='Enter') goBtn.click(); });
  
document.querySelector('#tab-home .quick').addEventListener('click', (e)=>{ const b=e.target.closest('button'); if(!b) return; q.value=b.dataset.q; goBtn.click(); });
  document.getElementById('back').onclick = ()=> view.contentWindow?.history.back();
  document.getElementById('forward').onclick = ()=> view.contentWindow?.history.forward();
  document.getElementById('reload').onclick = ()=> view.contentWindow?.location.reload();
  view.addEventListener('load', ()=> status.textContent='Done');

  // AI panel (simple prompt)
  aiBtn.onclick = async ()=>{
    const prompt = promptBox('Ask SKSmartAI…'); // simple prompt
    if(!prompt) return;
    if (SAFE.on() && SAFE.isBlocked(prompt)) return alert('Blocked by Safe Mode.');
    const via = await AI.viaBackend(prompt);
    const ans = via || await AI.instant(prompt);
    alert(ans);
  };
  function promptBox(msg){ try{ return window.prompt(msg)||''; }catch{ return ''; } }

  // Kodular voice hook
  window.receiveVoice = function(text){ q.value = text||''; if(text) goBtn.click(); };

  // Helpers
  function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m])); }
})();