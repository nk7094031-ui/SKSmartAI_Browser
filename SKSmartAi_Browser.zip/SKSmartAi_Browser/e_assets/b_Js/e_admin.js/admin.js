(function(){
  const lock = document.getElementById('admin-locked');
  const panel = document.getElementById('admin-panel');
  const pinIn = document.getElementById('admin-pin');
  const unlock = document.getElementById('admin-unlock');
  const notes = document.getElementById('admin-notes');
  const save = document.getElementById('admin-save');
  const backup = document.getElementById('admin-backup');
  const restore = document.getElementById('admin-restore');
  const aiEndpoint = document.getElementById('ai-endpoint');
  const aiTest = document.getElementById('ai-test');
  const aiLog = document.getElementById('ai-log');
  const cfgUrl = document.getElementById('cfg-url');
  const cfgApply = document.getElementById('cfg-apply');
  const cfgLog = document.getElementById('cfg-log');
  const safeToggle = document.getElementById('safe-toggle');

  function getPIN(){ return (DB.get('admin_pin','0000') || '0000'); }
  unlock.onclick = ()=>{
    if(pinIn.value.trim() === getPIN()){
      lock.classList.add('hide'); panel.classList.remove('hide');
      notes.value = DB.get('admin_notes','');
      aiEndpoint.value = DB.get('ai_ep','');
      cfgUrl.value = DB.get('cfg_url','');
      safeToggle.checked = !!SAFE.on();
    }else alert('Wrong PIN');
  };

  save.onclick = ()=>{ DB.set('admin_notes', notes.value); alert('Saved.'); };
  safeToggle.onchange = ()=> SAFE.set(!!safeToggle.checked);

  backup.onclick = ()=>{
    const data = {};
    ['bm','apps','notes','blog','wallets','admin_notes','ai_ep','cfg_url','admin_pin','safe_mode'].forEach(k=> data[k]=DB.get(k,null));
    const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
    const a = document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='sksmartai_backup.json'; a.click(); URL.revokeObjectURL(a.href);
  };
  restore.onchange = (e)=>{
    const f = e.target.files[0]; if(!f) return;
    const r = new FileReader(); r.onload = ()=>{
      try{
        const data = JSON.parse(r.result);
        Object.keys(data||{}).forEach(k=> DB.set(k, data[k]));
        alert('Restored. Reload app.');
      }catch{ alert('Invalid backup.'); }
    }; r.readAsText(f);
  };

  aiTest.onclick = async ()=>{
    const ep = aiEndpoint.value.trim(); DB.set('ai_ep', ep);
    if(!ep){ aiLog.textContent = 'Enter endpoint or leave empty to use built-in fallback.'; return; }
    aiLog.textContent='Calling…';
    try{
      const r = await fetch(ep, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({prompt:'Hello from SKSmartAI'})});
      aiLog.textContent = (await r.text()).slice(0,2000);
    }catch{ aiLog.textContent='Failed.'; }
  };

  cfgApply.onclick = async ()=>{
    const url = cfgUrl.value.trim(); DB.set('cfg_url', url);
    if(!url) return cfgLog.textContent='Enter a config URL.';
    cfgLog.textContent='Fetching…';
    try{
      const r = await fetch(url); const j = await r.json();
      // Example: { "apps":[{"title":"YouTube","url":"https://youtube.com"}], "bookmarks":[{"title":"Docs","url":"https://..."}], "theme":"dark" }
      if(j.apps) DB.set('apps', j.apps);
      if(j.bookmarks) DB.set('bm', j.bookmarks);
      if(j.admin_pin) DB.set('admin_pin', String(j.admin_pin));
      cfgLog.textContent = 'Applied. Check Apps/Bookmarks.';
    }catch{ cfgLog.textContent='Failed to fetch/apply.'; }
  };
})();